package com.rushi.minimallauncher

import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.rushi.minimallauncher.adapter.AppGridAdapter
import com.rushi.minimallauncher.databinding.ActivityMainBinding
import com.rushi.minimallauncher.utils.AppLauncher
import com.rushi.minimallauncher.viewmodel.LauncherViewModel

/**
 * MainActivity — the single screen of this launcher.
 *
 * Responsibilities:
 *   1. Ask the user to set this as default launcher (first run)
 *   2. Show RecyclerView grid of installed apps
 *   3. Handle search filtering
 *   4. Launch apps on tap
 *
 * Everything else is delegated to ViewModel (data) and Adapter (UI).
 */
class MainActivity : AppCompatActivity() {

    // ViewBinding auto-generates a binding class from activity_main.xml
    private lateinit var binding: ActivityMainBinding

    // ViewModel survives screen rotations
    private lateinit var viewModel: LauncherViewModel

    // Adapter for the RecyclerView grid
    private lateinit var adapter: AppGridAdapter

    // Launcher for requesting "set as default home app" on Android 10+
    private val roleRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* result handled in onResume */ }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout using ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViewModel()
        setupRecyclerView()
        setupSearchBar()
        observeLiveData()

        // Ask user to set as default launcher on first open
        if (savedInstanceState == null) {
            promptSetDefaultLauncher()
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh app list when returning (e.g., user installed/uninstalled an app)
        viewModel.loadApps()
    }

    // -------------------------------------------------------------------------
    // Setup methods
    // -------------------------------------------------------------------------

    private fun setupViewModel() {
        viewModel = ViewModelProvider(this)[LauncherViewModel::class.java]
    }

    private fun setupRecyclerView() {
        // Create adapter — lambda handles app launches
        adapter = AppGridAdapter { appInfo ->
            AppLauncher.launch(this, appInfo.packageName)
        }

        // 4-column grid layout
        val gridLayoutManager = GridLayoutManager(this, 4)

        binding.recyclerView.apply {
            layoutManager = gridLayoutManager
            adapter = this@MainActivity.adapter
            // Improve scroll performance — item sizes don't change
            setHasFixedSize(true)
        }
    }

    private fun setupSearchBar() {
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                // Update ViewModel with current search query
                viewModel.search(s?.toString() ?: "")
            }
        })
    }

    private fun observeLiveData() {
        // Observe loading state → show/hide progress indicator
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        // Observe filtered apps → update RecyclerView
        viewModel.filteredApps.observe(this) { apps ->
            adapter.submitList(apps)    // DiffUtil calculates changes automatically

            // Show empty state if no apps found (e.g., search returns nothing)
            binding.emptyStateText.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    // -------------------------------------------------------------------------
    // Default Launcher Setup
    // -------------------------------------------------------------------------

    /**
     * Prompts the user to set this app as the default launcher.
     *
     * Android 10+ has a RoleManager API for this.
     * On Android 8/9, we use the classic intent approach.
     */
    private fun promptSetDefaultLauncher() {
        if (isDefaultLauncher()) return   // already set, skip

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ — use RoleManager (proper API)
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_HOME)
            ) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
                roleRequestLauncher.launch(intent)
            }
        } else {
            // Android 8/9 — show a dialog explaining how to set default
            showSetDefaultDialog()
        }
    }

    /**
     * Checks if this app is currently the default HOME launcher.
     * Used to avoid re-prompting every time.
     */
    private fun isDefaultLauncher(): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
        }
        val resolveInfo = packageManager.resolveActivity(intent, 0)
        return resolveInfo?.activityInfo?.packageName == packageName
    }

    /**
     * Fallback dialog for Android 8/9 — guides user to system settings.
     */
    private fun showSetDefaultDialog() {
        AlertDialog.Builder(this)
            .setTitle("Set as Default Launcher")
            .setMessage("To use Minimal Launcher, please set it as your default home app in the next screen.")
            .setPositiveButton("OK") { _, _ ->
                // Open home app chooser
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                }
                startActivity(intent)
            }
            .setNegativeButton("Later", null)
            .show()
    }

    // -------------------------------------------------------------------------
    // Back button — launchers should NOT exit on back press
    // -------------------------------------------------------------------------

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Close search bar if open, otherwise do nothing
        // Real launchers don't exit on back press
        if (binding.searchEditText.text.isNotEmpty()) {
            binding.searchEditText.text.clear()
        }
        // Don't call super.onBackPressed() — prevents exiting launcher
    }
}
