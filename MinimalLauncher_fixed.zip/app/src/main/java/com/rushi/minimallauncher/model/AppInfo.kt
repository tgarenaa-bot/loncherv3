package com.rushi.minimallauncher.model

import android.graphics.drawable.Drawable

/**
 * Simple data class representing one installed app.
 *
 * @param name         Display name shown below the icon (e.g. "WhatsApp")
 * @param packageName  Unique package identifier (e.g. "com.whatsapp")
 * @param icon         The app's icon drawable, loaded from PackageManager
 */
data class AppInfo(
    val name: String,
    val packageName: String,
    val icon: Drawable
)
